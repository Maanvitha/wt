				Greenland Hotels And Restaurants

Steps for Executing the project :
1:you need to have html support browsers
2:you need to Xampp and start apache
3:you need to have three Static database files (in this project hotel,indian,cont
	are the three default datbases created)
4:Open home.html  file.
5:In home.html you can select either Hotels or restaurants
6:In hotels.html you can have the view of rooms
7:In order to book the rooms you have to login,if you are a new user  then 
   sign-up as a new user.
8:In Restaurants you need to register or else if you have an account already,
   you can login Directly
9:In that you can select either Continental Or Indian
10:Terms and conditions and details about Restaurants links

Concepts Used:
1.HTML
2.CSS
3.JAVA SCRIPT
4.PHP
5.JQUERY
6.MYSQL
7.Bootstrap ICONS
