RESORT BOOKING SYSTEM
(NAMASTE WANDERER)

	HARDWARE AND SOFTWARE REQUIREMENTS
HARDWARE :

PROCESSOR - 2.4 GHZ PROCESSOR SPEED
MEMORY - 2GB RAM
DISK SPACE - 500GB        

SOFTWARE:

OPERATING SYSTEM - WINDOWS
FRONT-END - HTML,CSS
BACK-END - PHP,MYSQL
SERVER-	XAMP SERVER

To run the program:
1.Start xamp server
	1.1 open Xamp control pannel and start Apache server and mysql .
2.Save the code of program into the path= "C:\xampp\htdocs" 
3.To run the code open a browser and search for "localhost/file name of code"


